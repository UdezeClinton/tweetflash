import styled from "styled-components";

export default styled.img`
  height: 200px;
  width: 100%;
  object-fit: cover;
`;
