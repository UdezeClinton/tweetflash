import React from "react";
import styled from "styled-components";

const Wrapper = styled.div`
	padding: 1rem;
`;

const Bookmarks = () => {
	return <Wrapper>This feature is not yet implemented</Wrapper>;
};

export default Bookmarks;
