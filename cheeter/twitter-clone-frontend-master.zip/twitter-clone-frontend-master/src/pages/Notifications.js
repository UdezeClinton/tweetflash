import React from "react";
import styled from "styled-components";

const Wrapper = styled.div`
  padding: 1rem;
`;

const Notifications = () => {
  return <Wrapper>coming soon...</Wrapper>;
};

export default Notifications;
